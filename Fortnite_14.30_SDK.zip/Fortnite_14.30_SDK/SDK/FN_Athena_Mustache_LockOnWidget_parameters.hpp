#pragma once

// Fortnite (14.30) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.Construct
struct UAthena_Mustache_LockOnWidget_C_Construct_Params
{
};

// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.MoveUI
struct UAthena_Mustache_LockOnWidget_C_MoveUI_Params
{
};

// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.Destruct
struct UAthena_Mustache_LockOnWidget_C_Destruct_Params
{
};

// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.WidgetAnimationEvt_Scale_K2Node_WidgetAnimationEvent_1
struct UAthena_Mustache_LockOnWidget_C_WidgetAnimationEvt_Scale_K2Node_WidgetAnimationEvent_1_Params
{
};

// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.ExecuteUbergraph_Athena_Mustache_LockOnWidget
struct UAthena_Mustache_LockOnWidget_C_ExecuteUbergraph_Athena_Mustache_LockOnWidget_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

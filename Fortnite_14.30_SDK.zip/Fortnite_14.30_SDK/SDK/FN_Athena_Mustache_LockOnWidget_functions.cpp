// Fortnite (14.30) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.Construct
// (BlueprintCosmetic, Event, Public, BlueprintEvent)

void UAthena_Mustache_LockOnWidget_C::Construct()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>("Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.Construct");

	UAthena_Mustache_LockOnWidget_C_Construct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.MoveUI
// (BlueprintCallable, BlueprintEvent)

void UAthena_Mustache_LockOnWidget_C::MoveUI()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>("Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.MoveUI");

	UAthena_Mustache_LockOnWidget_C_MoveUI_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.Destruct
// (BlueprintCosmetic, Event, Public, BlueprintEvent)

void UAthena_Mustache_LockOnWidget_C::Destruct()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>("Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.Destruct");

	UAthena_Mustache_LockOnWidget_C_Destruct_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.WidgetAnimationEvt_Scale_K2Node_WidgetAnimationEvent_1
// (BlueprintEvent)

void UAthena_Mustache_LockOnWidget_C::WidgetAnimationEvt_Scale_K2Node_WidgetAnimationEvent_1()
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>("Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.WidgetAnimationEvt_Scale_K2Node_WidgetAnimationEvent_1");

	UAthena_Mustache_LockOnWidget_C_WidgetAnimationEvt_Scale_K2Node_WidgetAnimationEvent_1_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.ExecuteUbergraph_Athena_Mustache_LockOnWidget
// (Final, HasDefaults)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UAthena_Mustache_LockOnWidget_C::ExecuteUbergraph_Athena_Mustache_LockOnWidget(int EntryPoint)
{
	static UFunction* fn = NULL;
	if(!fn)
		fn = UObject::FindObject<UFunction>("Function Athena_Mustache_LockOnWidget.Athena_Mustache_LockOnWidget_C.ExecuteUbergraph_Athena_Mustache_LockOnWidget");

	UAthena_Mustache_LockOnWidget_C_ExecuteUbergraph_Athena_Mustache_LockOnWidget_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

#pragma once

// Fortnite (14.30) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AthenaBoundActionButton.AthenaBoundActionButton_C.UpdateInputActionIconSize
struct UAthenaBoundActionButton_C_UpdateInputActionIconSize_Params
{
};

// Function AthenaBoundActionButton.AthenaBoundActionButton_C.Construct
struct UAthenaBoundActionButton_C_Construct_Params
{
};

// Function AthenaBoundActionButton.AthenaBoundActionButton_C.ExecuteUbergraph_AthenaBoundActionButton
struct UAthenaBoundActionButton_C_ExecuteUbergraph_AthenaBoundActionButton_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

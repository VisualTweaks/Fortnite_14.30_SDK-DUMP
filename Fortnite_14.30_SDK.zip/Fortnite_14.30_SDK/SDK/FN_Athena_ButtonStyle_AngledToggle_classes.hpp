#pragma once

// Fortnite (14.30) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Athena_ButtonStyle_AngledToggle.Athena_ButtonStyle_AngledToggle_C
// 0x0000 (0x0570 - 0x0570)
class UAthena_ButtonStyle_AngledToggle_C : public UCommonButtonStyle
{
public:

	static UClass* StaticClass()
	{
		static UClass* ptr;
		if(!ptr)
			ptr = UObject::FindClass("BlueprintGeneratedClass Athena_ButtonStyle_AngledToggle.Athena_ButtonStyle_AngledToggle_C");
		
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif

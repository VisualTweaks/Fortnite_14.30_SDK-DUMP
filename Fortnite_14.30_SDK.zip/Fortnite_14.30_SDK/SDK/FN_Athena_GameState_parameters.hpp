#pragma once

// Fortnite (14.30) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Athena_GameState.Athena_GameState_C.Timeline_0__FinishedFunc
struct AAthena_GameState_C_Timeline_0__FinishedFunc_Params
{
};

// Function Athena_GameState.Athena_GameState_C.Timeline_0__UpdateFunc
struct AAthena_GameState_C_Timeline_0__UpdateFunc_Params
{
};

// Function Athena_GameState.Athena_GameState_C.OnWinnerAnnounced
struct AAthena_GameState_C_OnWinnerAnnounced_Params
{
};

// Function Athena_GameState.Athena_GameState_C.ExecuteUbergraph_Athena_GameState
struct AAthena_GameState_C_ExecuteUbergraph_Athena_GameState_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
